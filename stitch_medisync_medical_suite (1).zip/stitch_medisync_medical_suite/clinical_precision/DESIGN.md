---
name: Clinical Precision
colors:
  surface: '#f8f9fa'
  surface-dim: '#d9dadb'
  surface-bright: '#f8f9fa'
  surface-container-lowest: '#ffffff'
  surface-container-low: '#f3f4f5'
  surface-container: '#edeeef'
  surface-container-high: '#e7e8e9'
  surface-container-highest: '#e1e3e4'
  on-surface: '#191c1d'
  on-surface-variant: '#434652'
  inverse-surface: '#2e3132'
  inverse-on-surface: '#f0f1f2'
  outline: '#737783'
  outline-variant: '#c3c6d4'
  surface-tint: '#2b5bb5'
  primary: '#003178'
  on-primary: '#ffffff'
  primary-container: '#0d47a1'
  on-primary-container: '#a1bbff'
  inverse-primary: '#b0c6ff'
  secondary: '#006a62'
  on-secondary: '#ffffff'
  secondary-container: '#81f3e5'
  on-secondary-container: '#006f66'
  tertiary: '#283838'
  on-tertiary: '#ffffff'
  tertiary-container: '#3f4f4f'
  on-tertiary-container: '#aec0bf'
  error: '#ba1a1a'
  on-error: '#ffffff'
  error-container: '#ffdad6'
  on-error-container: '#93000a'
  primary-fixed: '#d9e2ff'
  primary-fixed-dim: '#b0c6ff'
  on-primary-fixed: '#001945'
  on-primary-fixed-variant: '#00429c'
  secondary-fixed: '#84f5e8'
  secondary-fixed-dim: '#66d9cc'
  on-secondary-fixed: '#00201d'
  on-secondary-fixed-variant: '#005049'
  tertiary-fixed: '#d4e6e5'
  tertiary-fixed-dim: '#b8cac9'
  on-tertiary-fixed: '#0e1e1e'
  on-tertiary-fixed-variant: '#3a4a49'
  background: '#f8f9fa'
  on-background: '#191c1d'
  surface-variant: '#e1e3e4'
typography:
  h1:
    fontFamily: Inter
    fontSize: 32px
    fontWeight: '600'
    lineHeight: '1.2'
    letterSpacing: -0.02em
  h2:
    fontFamily: Inter
    fontSize: 24px
    fontWeight: '600'
    lineHeight: '1.3'
    letterSpacing: -0.01em
  h3:
    fontFamily: Inter
    fontSize: 20px
    fontWeight: '500'
    lineHeight: '1.4'
    letterSpacing: '0'
  body-lg:
    fontFamily: Inter
    fontSize: 16px
    fontWeight: '400'
    lineHeight: '1.6'
    letterSpacing: '0'
  body-md:
    fontFamily: Inter
    fontSize: 14px
    fontWeight: '400'
    lineHeight: '1.5'
    letterSpacing: '0'
  label-sm:
    fontFamily: Inter
    fontSize: 12px
    fontWeight: '600'
    lineHeight: '1'
    letterSpacing: 0.02em
  caption:
    fontFamily: Inter
    fontSize: 12px
    fontWeight: '400'
    lineHeight: '1.4'
    letterSpacing: '0'
rounded:
  sm: 0.25rem
  DEFAULT: 0.5rem
  md: 0.75rem
  lg: 1rem
  xl: 1.5rem
  full: 9999px
spacing:
  base: 4px
  xs: 4px
  sm: 8px
  md: 16px
  lg: 24px
  xl: 48px
  gutter: 20px
  margin: 32px
---

## Brand & Style
The design system is engineered for high-stakes healthcare environments where clarity and reliability are paramount. The brand personality is **Professional, Methodical, and Empathetic**, designed to instill confidence in both practitioners and administrative staff managing complex schedules.

The visual style follows a **Modern Corporate** aesthetic with a subtle **Tactile** influence. It prioritizes information density without sacrificing legibility. We utilize ample whitespace and structural grid alignment to reduce cognitive load, ensuring that critical patient data and scheduling conflicts are immediately identifiable.

## Colors
The palette is rooted in **Medical Blue**, a deep, authoritative hue that signifies stability and trust. This is balanced by **Soft Teal**, which represents healing and vitality, used primarily for constructive actions and positive status indicators. 

The UI relies on a high-ratio of **Crisp White** backgrounds to maintain a sterile, clean environment. **Subtle Light-Grays** are used to define logical groupings and panels, preventing the interface from appearing washed out while maintaining low visual noise.

## Typography
This design system utilizes **Inter** exclusively to leverage its exceptional legibility in data-heavy contexts. The typographic hierarchy is strictly enforced to guide the user's eye from high-level navigation to granular patient details.

Headers use semi-bold weights with slight negative letter spacing for a compact, authoritative feel. Body text is optimized for readability with a generous 1.6 line-height, ensuring that clinical notes and scheduling details are easy to scan during fast-paced shifts.

## Layout & Spacing
The layout follows a **12-column Fluid Grid** system with fixed sidebars. This allows the scheduling calendar—the core of the application—to expand and provide maximum visibility for daily and weekly views.

Spacing is governed by a 4px baseline grid. Components utilize consistent internal padding to maintain a spacious, premium feel. Margins between major UI sections are kept large (32px) to define clear boundaries between navigation, search, and the primary workspace.

## Elevation & Depth
Depth is conveyed through **Ambient Shadows** and **Tonal Layers**. Instead of harsh drop shadows, we use multi-layered, low-opacity blurs that mimic natural light falling on a physical surface.

- **Level 0 (Surface):** The main background (White).
- **Level 1 (Panels):** Subtle Gray backgrounds with no shadows, used for sidebars and header bars.
- **Level 2 (Cards):** White surfaces with a soft 10% opacity shadow and a 1px solid border (#E0E0E0).
- **Level 3 (Modals/Popovers):** Higher elevation with a more pronounced shadow to focus attention on critical patient intake or scheduling forms.

## Shapes
The design system employs a **12px (0.75rem) Corner Radius** as the standard for all primary containers, cards, and input fields. This moderate roundness strikes a balance between the clinical precision of sharp corners and the modern, approachable feel of rounded UI.

Smaller components like buttons and tags use the standard `rounded-md` (8px), while status badges and profile avatars utilize fully rounded pill shapes to distinguish them from interactive containers.

## Components

### Navigation & Sidebars
- **Sidebar:** Uses a light-gray panel (#F8F9FA) with a 1px right-border. Active states are indicated by a primary blue vertical bar (4px) on the left edge and a subtle teal background tint for the menu item.
- **Navigation Bar:** A crisp white top-bar with a soft bottom shadow. Contains global search and practitioner profile selectors.

### Interactive Cards
- **Appointment Cards:** White background, 12px corners, 1px light-gray border. Interactive cards should feature a subtle "lift" effect (increased shadow) on hover.
- **Status Indicators:** Color-coded vertical strips on the left side of cards (e.g., Green for confirmed, Orange for pending, Blue for checked-in).

### Form Elements & Inputs
- **Input Fields:** 12px rounded corners with a 1px neutral-gray border. On focus, the border transitions to Medical Blue with a subtle blue glow (outer shadow).
- **Buttons:** Primary buttons use a solid Medical Blue background. Secondary buttons use a white background with a teal border and teal text.

### Status Badges
- **Labels:** Small, pill-shaped tags with a 10% opacity background of the semantic color and a 100% opacity text color for maximum contrast (e.g., Soft Teal background with Dark Teal text).

### Medical-Specific Icons
- Use thin-stroke (1.5pt) icons with rounded caps. Icons should be functional and literal: stethoscopes for clinical records, calendars for scheduling, and shield icons for HIPAA-compliant data sections.